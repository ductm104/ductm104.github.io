const titleElement = document.getElementById("video-title");
const trackSelect = document.getElementById("track-select");
const modeSelect = document.getElementById("mode-select");
const renderButton = document.getElementById("render-button");
const copyButton = document.getElementById("copy-button");
const statusElement = document.getElementById("status");
const transcriptOutput = document.getElementById("transcript-output");

let currentContext = null;
let renderRequestId = 0;

function setStatus(message) {
  statusElement.textContent = message;
}

function setTranscriptText(value) {
  transcriptOutput.value = value;
  copyButton.disabled = !value.trim();
}

function describeTrack(track) {
  const kindLabel = track.kind === "asr" ? "Auto" : "Manual";
  const defaultLabel = track.isDefault ? "Default" : null;
  return [track.languageName, kindLabel, defaultLabel].filter(Boolean).join(" • ");
}

function setTrackOptions(tracks) {
  trackSelect.replaceChildren();

  for (const track of tracks) {
    const option = document.createElement("option");
    option.value = track.id;
    option.textContent = describeTrack(track);
    trackSelect.append(option);
  }

  const hasTracks = tracks.length > 0;
  trackSelect.disabled = !hasTracks;
  modeSelect.disabled = !hasTracks;
  renderButton.disabled = !hasTracks;
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  return tabs[0];
}

async function loadVideoContext() {
  setStatus("Checking the active tab for YouTube captions…");
  setTranscriptText("");
  renderButton.disabled = true;
  trackSelect.disabled = true;
  modeSelect.disabled = true;

  const activeTab = await getActiveTab();

  if (!activeTab || typeof activeTab.id !== "number") {
    titleElement.textContent = "No active tab available.";
    setTrackOptions([]);
    setStatus("Chrome did not expose an active tab to the popup.");
    return;
  }

  let response;

  try {
    response = await chrome.tabs.sendMessage(activeTab.id, {
      type: "YT_TCP_GET_VIDEO_CONTEXT"
    });
  } catch (_error) {
    titleElement.textContent = "This page is not supported.";
    setTrackOptions([]);
    setStatus("Open a YouTube watch page, then reopen the extension popup.");
    return;
  }

  if (!response || !response.ok) {
    titleElement.textContent = "No captions found.";
    setTrackOptions([]);

    switch (response && response.reason) {
      case "not-watch-page":
        setStatus("Open a standard YouTube watch page to inspect available caption tracks.");
        break;
      case "no-captions":
        setStatus("This video does not expose any caption tracks.");
        break;
      default:
        setStatus("The extension could not read caption metadata from this page.");
        break;
    }

    return;
  }

  currentContext = response.context;
  currentContext.tabId = activeTab.id;
  titleElement.textContent = currentContext.title || "Untitled video";
  setTrackOptions(currentContext.tracks);
  setStatus(`Found ${currentContext.tracks.length} caption track(s).`);

  if (currentContext.tracks.length > 0) {
    await renderTranscript();
  }
}

async function renderTranscript() {
  if (!currentContext) {
    setStatus("No caption track is loaded yet.");
    return;
  }

  const selectedTrack = currentContext.tracks.find((track) => track.id === trackSelect.value);

  if (!selectedTrack) {
    setStatus("Select a caption track first.");
    return;
  }

  const requestId = ++renderRequestId;
  renderButton.disabled = true;
  setStatus(`Loading ${selectedTrack.languageName} transcript…`);

  const response = await chrome.runtime.sendMessage({
    type: "YT_TCP_RENDER_TRACK",
    payload: {
      tabId: currentContext.tabId,
      videoId: currentContext.videoId,
      trackId: selectedTrack.id,
      title: currentContext.title,
      languageCode: selectedTrack.languageCode || selectedTrack.languageName,
      baseUrl: selectedTrack.baseUrl,
      outputMode: modeSelect.value
    }
  });

  if (requestId !== renderRequestId) {
    return;
  }

  renderButton.disabled = false;

  if (!response || !response.ok) {
    setTranscriptText("");
    setStatus(response && response.error ? response.error : "Transcript render failed.");
    return;
  }

  setTranscriptText(response.content);
  setStatus(`Loaded ${response.chunkCount} transcript chunk(s) from ${response.segmentCount} caption segments.`);
}

async function copyTranscript() {
  const value = transcriptOutput.value.trim();

  if (!value) {
    setStatus("There is no transcript text to copy.");
    return;
  }

  try {
    await navigator.clipboard.writeText(value);
    setStatus("Transcript copied to clipboard.");
    return;
  } catch (_error) {
    transcriptOutput.focus();
    transcriptOutput.select();
    const success = document.execCommand("copy");

    if (!success) {
      throw new Error("Clipboard copy failed");
    }

    setStatus("Transcript copied to clipboard.");
  }
}

renderButton.addEventListener("click", () => {
  renderTranscript().catch((error) => {
    renderButton.disabled = false;
    setStatus(error instanceof Error ? error.message : String(error));
  });
});

trackSelect.addEventListener("change", () => {
  renderTranscript().catch((error) => {
    renderButton.disabled = false;
    setStatus(error instanceof Error ? error.message : String(error));
  });
});

modeSelect.addEventListener("change", () => {
  renderTranscript().catch((error) => {
    renderButton.disabled = false;
    setStatus(error instanceof Error ? error.message : String(error));
  });
});

copyButton.addEventListener("click", () => {
  copyTranscript().catch((error) => {
    setStatus(error instanceof Error ? error.message : String(error));
  });
});

loadVideoContext().catch((error) => {
  titleElement.textContent = "Failed to load.";
  setTrackOptions([]);
  setStatus(error instanceof Error ? error.message : String(error));
});

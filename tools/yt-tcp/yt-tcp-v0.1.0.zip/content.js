const REQUEST_EVENT = "yt-tcp:request-context";
const RESPONSE_EVENT = "yt-tcp:response-context";
const REQUEST_TIMEOUT_MS = 1500;

function requestPageContext() {
  return new Promise((resolve) => {
    const timeoutId = window.setTimeout(() => {
      window.removeEventListener(RESPONSE_EVENT, onResponse);
      resolve({
        ok: false,
        reason: "page-response-timeout"
      });
    }, REQUEST_TIMEOUT_MS);

    function onResponse(event) {
      window.clearTimeout(timeoutId);
      window.removeEventListener(RESPONSE_EVENT, onResponse);
      resolve(event.detail || { ok: false, reason: "empty-page-response" });
    }

    window.addEventListener(RESPONSE_EVENT, onResponse, { once: true });
    window.dispatchEvent(new CustomEvent(REQUEST_EVENT));
  });
}

async function fetchFromPageContext(url, options = {}) {
  const response = await fetch(url, {
    method: options.method || "GET",
    headers: options.headers || {},
    body: options.body,
    credentials: "include"
  });

  const text = await response.text();

  return {
    ok: response.ok,
    status: response.status,
    statusText: response.statusText,
    contentType: response.headers.get("content-type") || "",
    text
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message) {
    return undefined;
  }

  if (message.type === "YT_TCP_GET_VIDEO_CONTEXT") {
    requestPageContext()
      .then((result) => sendResponse(result))
      .catch((error) => {
        sendResponse({
          ok: false,
          reason: "content-script-error",
          error: error instanceof Error ? error.message : String(error)
        });
      });

    return true;
  }

  if (message.type === "YT_TCP_FETCH_URL") {
    fetchFromPageContext(message.url, message.options)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => {
        sendResponse({
          ok: false,
          reason: "content-fetch-error",
          error: error instanceof Error ? error.message : String(error)
        });
      });

    return true;
  }

  return undefined;
});

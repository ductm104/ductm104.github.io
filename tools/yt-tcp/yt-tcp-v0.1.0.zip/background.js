const INNERTUBE_API_URL = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false";
const INNERTUBE_CLIENT_VERSION = "20.10.38";
const INNERTUBE_CONTEXT = {
  client: {
    clientName: "ANDROID",
    clientVersion: INNERTUBE_CLIENT_VERSION
  }
};

function logError(event, details) {
  console.error("[YT TCP]", event, details);
}

async function fetchViaTab(tabId, url, options = {}) {
  if (typeof tabId !== "number") {
    throw new Error("Missing tabId for page-context fetch");
  }

  const response = await chrome.tabs.sendMessage(tabId, {
    type: "YT_TCP_FETCH_URL",
    url,
    options
  });

  if (!response || !response.ok) {
    throw new Error(response && response.error ? response.error : "Page-context fetch failed");
  }

  return response.result;
}

function decodeHtmlEntities(text) {
  const namedEntities = {
    amp: "&",
    lt: "<",
    gt: ">",
    quot: "\"",
    apos: "'",
    nbsp: " "
  };

  return text.replace(/&(#x?[0-9a-fA-F]+|[a-zA-Z]+);/g, (_match, entity) => {
    if (entity[0] === "#") {
      const isHex = entity[1] === "x" || entity[1] === "X";
      const rawValue = isHex ? entity.slice(2) : entity.slice(1);
      const codePoint = Number.parseInt(rawValue, isHex ? 16 : 10);
      return Number.isNaN(codePoint) ? "" : String.fromCodePoint(codePoint);
    }

    return Object.prototype.hasOwnProperty.call(namedEntities, entity)
      ? namedEntities[entity]
      : "";
  });
}

function normalizeCaptionText(text) {
  return decodeHtmlEntities(text.replace(/<br\s*\/?>/gi, "\n"))
    .replace(/\r\n/g, "\n")
    .replace(/[ \t]+\n[ \t]+/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function stripXmlMarkup(text) {
  return text
    .replace(/<\/?s\b[^>]*>/gi, "")
    .replace(/<\/?font\b[^>]*>/gi, "")
    .replace(/<\/?[^>]+>/g, "");
}

function parseXmlCueBlocks(xmlText, tagName, startAttribute, durationAttribute, unitDivisor = 1) {
  const pattern = new RegExp(`<${tagName}\\b([^>]*)>([\\s\\S]*?)<\\/${tagName}>`, "gi");
  const segments = [];
  let match;

  while ((match = pattern.exec(xmlText)) !== null) {
    const attributes = match[1] || "";
    const rawBody = stripXmlMarkup(match[2] || "");
    const body = normalizeCaptionText(rawBody);
    const startMatch = attributes.match(new RegExp(`\\b${startAttribute}="([^"]+)"`, "i"));
    const durationMatch = attributes.match(new RegExp(`\\b${durationAttribute}="([^"]+)"`, "i"));
    const start = startMatch ? Number.parseFloat(startMatch[1]) / unitDivisor : 0;
    const duration = durationMatch ? Number.parseFloat(durationMatch[1]) / unitDivisor : 0;

    if (!body) {
      continue;
    }

    segments.push({
      start,
      duration,
      text: body
    });
  }

  return segments;
}

function parseXmlTranscript(xmlText) {
  const textSegments = parseXmlCueBlocks(xmlText, "text", "start", "dur");

  if (textSegments.length > 0) {
    return textSegments;
  }

  return parseXmlCueBlocks(xmlText, "p", "t", "d", 1000);
}

function extractRunsText(segment) {
  if (!segment || !Array.isArray(segment.segs)) {
    return "";
  }

  return segment.segs.map((part) => (typeof part.utf8 === "string" ? part.utf8 : "")).join("");
}

function parseJsonTranscript(jsonText) {
  const payload = JSON.parse(jsonText);

  if (!payload || !Array.isArray(payload.events)) {
    return [];
  }

  return payload.events
    .filter((event) => Array.isArray(event.segs) && typeof event.tStartMs === "number")
    .map((event) => ({
      start: event.tStartMs / 1000,
      duration: typeof event.dDurationMs === "number" ? event.dDurationMs / 1000 : 0,
      text: normalizeCaptionText(extractRunsText(event))
    }))
    .filter((segment) => segment.text);
}

function parseTranscriptResponse(rawText) {
  const trimmed = rawText.trim();

  if (!trimmed) {
    return [];
  }

  if (trimmed.startsWith("{")) {
    return parseJsonTranscript(trimmed);
  }

  if (trimmed.includes("<text") || trimmed.includes("<p")) {
    return parseXmlTranscript(trimmed);
  }

  return [];
}

function withJson3Format(baseUrl) {
  try {
    const url = new URL(baseUrl);
    url.searchParams.set("fmt", "json3");
    return url.toString();
  } catch (_error) {
    return baseUrl;
  }
}

function getTrackNameText(name) {
  if (!name) {
    return "";
  }

  if (typeof name.simpleText === "string") {
    return name.simpleText;
  }

  if (Array.isArray(name.runs)) {
    return name.runs
      .map((run) => (typeof run.text === "string" ? run.text : ""))
      .join("")
      .trim();
  }

  return "";
}

function normalizeInnerTubeTracks(captionTracks) {
  if (!Array.isArray(captionTracks)) {
    return [];
  }

  return captionTracks
    .map((track, index) => ({
      id: track.vssId || `${track.languageCode || "unknown"}-${index}`,
      languageCode: track.languageCode || "",
      languageName: getTrackNameText(track.name) || track.languageCode || "Unknown",
      baseUrl: track.baseUrl || ""
    }))
    .filter((track) => track.baseUrl);
}

async function fetchTracksViaInnerTube(videoId, tabId) {
  const response = await fetchViaTab(tabId, INNERTUBE_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      context: INNERTUBE_CONTEXT,
      videoId
    })
  });

  if (!response.ok) {
    return [];
  }

  let payload;

  try {
    payload = JSON.parse(response.text);
  } catch (_error) {
    return [];
  }

  return normalizeInnerTubeTracks(
    payload &&
      payload.captions &&
      payload.captions.playerCaptionsTracklistRenderer &&
      payload.captions.playerCaptionsTracklistRenderer.captionTracks
  );
}

async function fetchTranscriptSegmentsFromUrl(baseUrl, tabId) {
  const candidateUrls = [baseUrl, withJson3Format(baseUrl)];
  let lastError = null;

  for (const candidateUrl of candidateUrls) {
    const response = await fetchViaTab(tabId, candidateUrl);

    if (!response.ok) {
      lastError = new Error(`Caption fetch failed with status ${response.status}`);
      continue;
    }

    const segments = parseTranscriptResponse(response.text);

    if (segments.length > 0) {
      return segments;
    }

    lastError = new Error("Caption track returned no usable segments");
  }

  throw lastError || new Error("Caption track download failed");
}

async function fetchTranscriptSegments(payload) {
  if (payload.baseUrl) {
    try {
      return await fetchTranscriptSegmentsFromUrl(payload.baseUrl, payload.tabId);
    } catch (error) {
      if (!payload.videoId) {
        throw error;
      }
    }
  }

  if (!payload.videoId) {
    throw new Error("Missing videoId for caption lookup");
  }

  const tracks = await fetchTracksViaInnerTube(payload.videoId, payload.tabId);
  const selectedTrack =
    tracks.find((track) => track.languageCode === payload.languageCode) ||
    tracks.find((track) => track.id === payload.trackId) ||
    tracks[0];

  if (!selectedTrack || !selectedTrack.baseUrl) {
    throw new Error("No caption track URL available");
  }

  return fetchTranscriptSegmentsFromUrl(selectedTrack.baseUrl, payload.tabId);
}

function normalizeSegmentLine(text) {
  return text
    .replace(/\s+/g, " ")
    .replace(/\s+([,.;:!?])/g, "$1")
    .trim();
}

function sanitizeSegments(segments) {
  const sanitized = [];

  for (const segment of segments) {
    const text = normalizeSegmentLine(segment.text);

    if (!text) {
      continue;
    }

    const previous = sanitized[sanitized.length - 1];

    if (previous && previous.text === text) {
      previous.duration = Math.max(previous.duration, segment.start + segment.duration - previous.start);
      continue;
    }

    if (
      previous &&
      text.length > previous.text.length &&
      text.startsWith(previous.text) &&
      segment.start - previous.start < 1.5
    ) {
      previous.text = text;
      previous.duration = Math.max(previous.duration, segment.start + segment.duration - previous.start);
      continue;
    }

    sanitized.push({
      start: segment.start,
      duration: segment.duration,
      text
    });
  }

  return sanitized;
}

function shouldBreakChunk(currentChunk, nextSegment) {
  const currentEnd = currentChunk.lastStart + currentChunk.lastDuration;
  const gap = Math.max(0, nextSegment.start - currentEnd);
  const nextLength = currentChunk.text.length + 1 + nextSegment.text.length;
  const nextDuration = nextSegment.start + nextSegment.duration - currentChunk.start;
  const endsSentence = /[.!?]["')\]]?$/.test(currentChunk.text);

  if (gap >= 2.6) {
    return true;
  }

  if (gap >= 1.4 && currentChunk.text.length >= 70) {
    return true;
  }

  if (endsSentence && currentChunk.text.length >= 120) {
    return true;
  }

  if (nextLength > 260) {
    return true;
  }

  if (nextDuration > 18) {
    return true;
  }

  return false;
}

function buildChunks(segments) {
  const cleaned = sanitizeSegments(segments);
  const chunks = [];
  let currentChunk = null;

  for (const segment of cleaned) {
    if (!currentChunk) {
      currentChunk = {
        start: segment.start,
        lastStart: segment.start,
        lastDuration: segment.duration,
        text: segment.text
      };
      continue;
    }

    if (shouldBreakChunk(currentChunk, segment)) {
      chunks.push({
        start: currentChunk.start,
        text: currentChunk.text.trim()
      });
      currentChunk = {
        start: segment.start,
        lastStart: segment.start,
        lastDuration: segment.duration,
        text: segment.text
      };
      continue;
    }

    currentChunk.text = `${currentChunk.text} ${segment.text}`.replace(/\s+/g, " ").trim();
    currentChunk.lastStart = segment.start;
    currentChunk.lastDuration = segment.duration;
  }

  if (currentChunk) {
    chunks.push({
      start: currentChunk.start,
      text: currentChunk.text.trim()
    });
  }

  if (chunks.length > 1) {
    const merged = [];

    for (const chunk of chunks) {
      const previous = merged[merged.length - 1];

      if (previous && chunk.text.length < 45 && previous.text.length < 240) {
        previous.text = `${previous.text} ${chunk.text}`.replace(/\s+/g, " ").trim();
      } else {
        merged.push(chunk);
      }
    }

    return merged;
  }

  return chunks;
}

function formatTimestamp(seconds) {
  const totalSeconds = Math.max(0, Math.floor(seconds));
  const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, "0");
  const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, "0");
  const secs = String(totalSeconds % 60).padStart(2, "0");
  return `${hours}:${minutes}:${secs}`;
}

function formatTranscript(chunks, mode) {
  if (mode === "timestamped") {
    return chunks.map((chunk) => `[${formatTimestamp(chunk.start)}] ${chunk.text}`).join("\n\n");
  }

  return chunks.map((chunk) => chunk.text).join("\n\n");
}

async function handleRenderRequest(payload) {
  const segments = await fetchTranscriptSegments(payload);
  const chunks = buildChunks(segments);
  const content = formatTranscript(chunks, payload.outputMode);

  return {
    ok: true,
    content,
    chunkCount: chunks.length,
    segmentCount: segments.length
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== "YT_TCP_RENDER_TRACK") {
    return undefined;
  }

  handleRenderRequest(message.payload)
    .then((result) => sendResponse(result))
    .catch((error) => {
      logError("render_failed", {
        error: error instanceof Error ? error.message : String(error)
      });
      sendResponse({
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      });
    });

  return true;
});

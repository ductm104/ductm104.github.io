(function () {
  const REQUEST_EVENT = "yt-tcp:request-context";
  const RESPONSE_EVENT = "yt-tcp:response-context";

  function getTextValue(value) {
    if (!value) {
      return "";
    }

    if (typeof value.simpleText === "string") {
      return value.simpleText;
    }

    if (Array.isArray(value.runs)) {
      return value.runs
        .map((run) => (typeof run.text === "string" ? run.text : ""))
        .join("")
        .trim();
    }

    return "";
  }

  function normalizePlayerResponse(candidate) {
    if (!candidate) {
      return null;
    }

    if (typeof candidate === "string") {
      try {
        return JSON.parse(candidate);
      } catch (_error) {
        return null;
      }
    }

    if (typeof candidate === "object") {
      return candidate;
    }

    return null;
  }

  function getPlayerResponse(videoId) {
    const candidates = [
      window.ytInitialPlayerResponse,
      window.ytplayer && window.ytplayer.config && window.ytplayer.config.args
        ? window.ytplayer.config.args.raw_player_response
        : null,
      window.ytplayer && window.ytplayer.config && window.ytplayer.config.args
        ? window.ytplayer.config.args.player_response
        : null
    ];

    for (const candidate of candidates) {
      const playerResponse = normalizePlayerResponse(candidate);

      if (!playerResponse || !playerResponse.videoDetails) {
        continue;
      }

      if (!videoId || playerResponse.videoDetails.videoId === videoId) {
        return playerResponse;
      }
    }

    return null;
  }

  function getWatchContext() {
    const url = new URL(window.location.href);
    const videoId = url.searchParams.get("v") || "";

    if (url.pathname !== "/watch" || !videoId) {
      return {
        ok: false,
        reason: "not-watch-page"
      };
    }

    const playerResponse = getPlayerResponse(videoId);

    if (!playerResponse) {
      return {
        ok: false,
        reason: "missing-player-response"
      };
    }

    const videoDetails = playerResponse.videoDetails || {};
    const tracklist =
      playerResponse.captions &&
      playerResponse.captions.playerCaptionsTracklistRenderer;

    if (!tracklist || !Array.isArray(tracklist.captionTracks) || tracklist.captionTracks.length === 0) {
      return {
        ok: false,
        reason: "no-captions",
        videoId: videoDetails.videoId || videoId,
        title: videoDetails.title || document.title.replace(/\s*-\s*YouTube$/, "")
      };
    }

    const preferredIndices = new Set();
    const defaultAudioTrackIndex =
      typeof tracklist.defaultAudioTrackIndex === "number"
        ? tracklist.defaultAudioTrackIndex
        : -1;
    const defaultAudioTrack =
      defaultAudioTrackIndex >= 0 &&
      Array.isArray(tracklist.audioTracks) &&
      tracklist.audioTracks[defaultAudioTrackIndex]
        ? tracklist.audioTracks[defaultAudioTrackIndex]
        : null;

    if (defaultAudioTrack && Array.isArray(defaultAudioTrack.captionTrackIndices)) {
      defaultAudioTrack.captionTrackIndices.forEach((index) => {
        if (Number.isInteger(index)) {
          preferredIndices.add(index);
        }
      });
    }

    const tracks = tracklist.captionTracks
      .map((track, index) => ({
        id: track.vssId || `${track.languageCode || "unknown"}-${index}`,
        languageCode: track.languageCode || "",
        languageName: getTextValue(track.name) || track.languageCode || "Unknown",
        kind: track.kind || "standard",
        isTranslatable: Boolean(track.isTranslatable),
        baseUrl: track.baseUrl || "",
        isDefault: preferredIndices.has(index)
      }))
      .filter((track) => track.baseUrl);

    tracks.sort((left, right) => {
      if (left.isDefault !== right.isDefault) {
        return left.isDefault ? -1 : 1;
      }

      return left.languageName.localeCompare(right.languageName);
    });

    return {
      ok: true,
      context: {
        videoId: videoDetails.videoId || videoId,
        title: videoDetails.title || document.title.replace(/\s*-\s*YouTube$/, ""),
        tracks
      }
    };
  }

  window.addEventListener(REQUEST_EVENT, () => {
    window.dispatchEvent(
      new CustomEvent(RESPONSE_EVENT, {
        detail: getWatchContext()
      })
    );
  });
})();
